function [Is] = ver_eq3(I)
l = length(I); 

Is = unique(I); 

end